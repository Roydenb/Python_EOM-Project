# When done add your name, surname and class as a comment to your sourcecode.
# Zip the project and submit the assignment to LMS.
# To zip the  folder ona linux machine, right click on the folder and select compress.
# By default thezip option should be selected, then just click on “Create”. Submit the file youjust created on LMS.
# 30 November 2020, 4h30pm

# L-O-T-T-E-R-Y
# NUMBERS CHALLENGE

# STEP1- GENERATE 6 RANDOM NUMBERS 1-49
# NEED TO DISPLAY ON SCREEN, SHORTED IN ASCENDING ORDER
# EACH NUMBER IS UNIQUE/NEED TO BE

# REQUIREMENTS
# Onlyplayerswhoareabove18yearsareallowedtoplaylotto.
# Yourprogramshouldtakecareofthevalidation(Exceptions/ErrorHandling).
# Theprogramshouldalsoautomaticallywritetheresultstoatextfileincludingthecurrentdate.
# ThetextfileshouldreflectthetotalamountwhichtheIthubalotteryhastopaytothewinnersandshowwinnersineachcategory.


# Start by identifying the software development methodology which you are going to use.
# Write a report why you have selected that approach.
# Also write a report on thefollowing to indicate your understanding of the requirements:

# Flowcharts​, ​algorithms​, ​pseudocodes​ or ​inputprocessing​​output tables​.


# 6 correct numbers (10, 000 000.00)
# 5 correct numbers (8,584.00)
# 4 correct numbers (2,384.00)
# 3 correct numbers (100.50)
# 2 correct numbers (20.00)
